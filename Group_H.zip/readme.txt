需要檔案:
"ALL.csv" 
"ImdbRunAge0531_test.csv" 
"ImdbRunAge0531_train.csv"

需要的額外模組:
sys
PyQt5.QtWidgets
PyQt5
time

程式:
程式執行後需大約等待10sec會產生一個使用者介面，於介面左上角的空格內可以
填入電影名稱。
電影名稱參考範例:
Jurassic World Dominion
Emily in Paris
輸入以上電影名稱將會有輔助圖片於介面左下角顯示
也可以從"ImdbRunAge0531_test.csv"檔案中輸入電影名稱。
!!!!!!!!!!!!!!!!!!!!!!!!!!注意!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
電影名稱必須完全相同才會有結果